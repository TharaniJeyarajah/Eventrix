﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Eventrix
{
    /// <summary>
    /// Interaction logic for Home.xaml
    /// </summary>
    public partial class Home : Page
    {
        public Home()
        {
            InitializeComponent();

        }

        private void HomeButton_Click2(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Home.xaml", UriKind.Relative));
        }

        private void FeedbackButton_Click2(object sender, RoutedEventArgs e)
        {
            // Navigate to the FeedbackPage
            NavigationService.Navigate(new Uri("FeedbackPage.xaml", UriKind.Relative));
        }

        private void ContactButton_Click2(object sender, RoutedEventArgs e)
        {
            // Navigate to the ContactPage
            NavigationService.Navigate(new Uri("ContactPage.xaml", UriKind.Relative));
        }

        private void RegisterButton_Click2(object sender, RoutedEventArgs e)
        {
            // Navigate to the ContactPage
            NavigationService.Navigate(new Uri("Register.xaml", UriKind.Relative));
        }

        private void BookButton_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of the Register page and navigate to it
            NavigationService.Navigate(new Uri("Register.xaml", UriKind.Relative));
        }

    }
}
