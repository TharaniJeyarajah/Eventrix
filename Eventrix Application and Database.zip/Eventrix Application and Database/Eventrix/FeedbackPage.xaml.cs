﻿using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using MySql.Data.MySqlClient;

namespace Eventrix
{
    public partial class FeedbackPage : Page
    {
        

        private string connectionString = "server=localhost;user=root;database=event_management;password=";

        public FeedbackPage()
        {
            InitializeComponent();

        }


        private void TextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Regex pattern to allow numbers and the plus sign (+)
            Regex regex = new Regex("[^0-9+]+");

            // If the input contains characters other than numbers or the plus sign, cancel the input
            e.Handled = regex.IsMatch(e.Text);
        }


        // Other event handlers...

        private void SaveFeedback_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName.Text;
            string email = txtEmail.Text;
            string contact = txtContact.Text;
            string comments = txtComments.Text;

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(contact))
            {
                MessageBox.Show("Name, Email, and Contact cannot be empty.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return; // Stop further processing
            }

            if (!IsValidEmail(email))
            {
                MessageBox.Show("Please enter a valid email address.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return; // Stop further processing
            }

            string connStr = "server=localhost;user=root;database=event_management;port=3306;password=";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {

                Console.WriteLine("Connecting to MySQL...");
                conn.Open();

                string query = "INSERT INTO feedback (name, email, contact, comments) VALUES (@name, @email, @feedback, @comments)";
                MySqlCommand command = new MySqlCommand(query, conn);
                command.Parameters.AddWithValue("@name", name);
                command.Parameters.AddWithValue("@email", email);
                command.Parameters.AddWithValue("@feedback", contact);
                command.Parameters.AddWithValue("@comments", comments);
                command.ExecuteNonQuery();

                MessageBox.Show("Feedback saved successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Not Connected");

                Console.WriteLine(ex.ToString());
            }

            conn.Close();
            Console.WriteLine("Done.");
        }

        // Function to validate email format using regex
        private bool IsValidEmail(string email)
        {
            // Email regex pattern
            string emailPattern = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";

            return Regex.IsMatch(email, emailPattern);
        }

        private void ShowCustomMessageBox(string message)
        {
            var customMessageBox = new CustomMessageBox(message);
            customMessageBox.ShowDialog();
        }
        private void HomeButton_Click4(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Home.xaml", UriKind.Relative));
        }

        private void FeedbackButton_Click4(object sender, RoutedEventArgs e)
        {
            // Navigate to the FeedbackPage
            NavigationService.Navigate(new Uri("FeedbackPage.xaml", UriKind.Relative));
        }

        private void ContactButton_Click4(object sender, RoutedEventArgs e)
        {
            // Navigate to the ContactPage
            NavigationService.Navigate(new Uri("ContactPage.xaml", UriKind.Relative));
        }
        private void RegisterButton_Click4(object sender, RoutedEventArgs e)
        {
            // Navigate to the ContactPage
            NavigationService.Navigate(new Uri("Register.xaml", UriKind.Relative));
        }
    }
}
