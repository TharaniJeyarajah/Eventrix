/*
SQLyog Community v12.4.3 (32 bit)
MySQL - 10.4.28-MariaDB : Database - event_management
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`event_management` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `event_management`;

/*Table structure for table `feedback` */

DROP TABLE IF EXISTS `feedback`;

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `comments` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `feedback` */

/*Table structure for table `registers` */

DROP TABLE IF EXISTS `registers`;

CREATE TABLE `registers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `event_type` varchar(50) DEFAULT NULL,
  `type_of_plan` varchar(50) DEFAULT NULL,
  `number_of_days` int(11) DEFAULT NULL,
  `comments` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `registers` */

insert  into `registers`(`id`,`name`,`email`,`contact`,`address`,`province`,`city`,`postal_code`,`event_type`,`type_of_plan`,`number_of_days`,`comments`) values 
(49,'Thara weds Theva','thara@gmail.com','07272727272','Thrani Jeyarajah,Kopai Center','Nothern province','Jaffna','42000','Marriage','Gold - $1500 per day',5,'I need very quick arrangements'),
(50,'Thara Weds Theva','thara@gmail.com','0882822822','Kopai Center, Kopai','Northen Province','Jaffna','42000','Marriage','Gold - $1500 per day',5,'we will do allarrangement 3 days before'),
(51,'Thara Weds Theva','thara@gmail.com','0882822822','Kopai Center, Kopai','Northen Province','Jaffna','42000','Marriage','Gold - $1500 per day',5,'we will do allarrangement 3 days before'),
(52,'Thara Weds Theva','thara@gmail.com','0928282882','Kopai Center,Kopai','Northern Province','Jaffna','42000','Marriage','Gold - $1500 per day',5,'');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
