﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Eventrix
{
    /// <summary>
    /// Interaction logic for Register.xaml
    /// </summary>
    /// 
 
    public partial class Register : Page
    {
        public Register()
        {
            InitializeComponent();
        }

        int amount;

        private void TextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Regex pattern to allow numbers and the plus sign (+)
            Regex regex = new Regex("[^0-9+]+");

            // If the input contains characters other than numbers or the plus sign, cancel the input
            e.Handled = regex.IsMatch(e.Text);
        }

        private void TextBox_PreviewTextInput2(object sender, TextCompositionEventArgs e)
        {
            // Regex pattern to allow numbers and the plus sign (+)
            Regex regex = new Regex("[^0-9]");

            // If the input contains characters other than numbers or the plus sign, cancel the input
            e.Handled = regex.IsMatch(e.Text);
        }


        String txtPlan;
        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;


            if (radioButton != null && radioButton.IsChecked == true)
            {
                txtPlan = radioButton.Content.ToString();
                string numericValue = Regex.Match(txtPlan, @"\d+").Value;

                if (!string.IsNullOrEmpty(numericValue))
                {
                   amount = int.Parse(numericValue);
           
                }
            }
        }

        private void SaveRegistration_Click(object sender, RoutedEventArgs e)
        {


            string name = txtName.Text;
            string email = txtEmail.Text;
            string type = txtType.Text;
            string contact = txtContact.Text;
            string comments = txtComments.Text;
            string address = txtAddress.Text;
            string province = txtProvince.Text;
            string city = txtCity.Text;
            string postal = txtPostal.Text;
            string plan = txtPlan;
            string days = txtDays.Text;


            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(type) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(contact) || string.IsNullOrEmpty(address) || string.IsNullOrEmpty(plan) || string.IsNullOrEmpty(days))
            {
                MessageBox.Show("Name,Event Type, Email,Contact,Address,Type of Plan and Number of days cannot be empty.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return; // Stop further processing
            }

            if (!IsValidEmail(email))
            {
                MessageBox.Show("Please enter a valid email address.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return; // Stop further processing
            }

            string connStr = "server=localhost;user=root;database=event_management;port=3306;password=";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {

                Console.WriteLine("Connecting to MySQL...");
                conn.Open();


                string query = "INSERT INTO registers (name, email, contact,address,province,city,postal_code,event_type,type_of_plan,number_of_days,comments) VALUES (@name, @email, @contact,@address,@province,@city,@postal,@type,@plan,@days,@comments)";
                MySqlCommand command = new MySqlCommand(query, conn);
                command.Parameters.AddWithValue("@name", name);
                command.Parameters.AddWithValue("@email", email);
                command.Parameters.AddWithValue("@contact", contact);
                command.Parameters.AddWithValue("@address", address);
                command.Parameters.AddWithValue("@province", province);
                command.Parameters.AddWithValue("@city", city);
                command.Parameters.AddWithValue("@postal", postal);
                command.Parameters.AddWithValue("@type", type);
                command.Parameters.AddWithValue("@plan", plan);
                command.Parameters.AddWithValue("@days", days);
                command.Parameters.AddWithValue("@comments", comments);
                command.ExecuteNonQuery();

                // Generate the bill
                string billContent = GenerateBill(name, email, type, contact, address, province, city, postal, plan, days, comments);

                // Generate a random filename for the bill
                string fileName = GenerateRandomFileName();

                // Specify the directory to save bills
                string billsDirectory = "bills"; // Adjust as per your project's structure
                string filePath = System.IO.Path.Combine(billsDirectory, fileName); // System.IO.Path

                // Save the bill content to a file
                string projectDirectory = Directory.GetParent(Environment.CurrentDirectory)?.Parent?.Parent?.FullName;
                string fullPath = System.IO.Path.Combine(projectDirectory, filePath); // System.IO.Path
                

                System.IO.File.WriteAllText(fullPath, billContent);

                // Show a message or perform any other necessary action
                MessageBox.Show("Event Registered! Bill has been generated and saved.");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Not Connected");

                Console.WriteLine(ex.ToString());
            }

            conn.Close();
            Console.WriteLine("Done.");

            // Generate the bill
           

        }

        private string GenerateRandomFileName()
        {
            string timestamp = DateTime.Now.ToString("yyyyMMddHHmmssfff"); // Current timestamp
            string randomPart = System.IO.Path.GetRandomFileName().Replace(".", ""); // Random part

            return $"{timestamp}_{randomPart}.txt"; // Adjust the file extension or format as needed
        }

        private string GenerateBill(string name, string email, string type, string contact, string address, string province, string city, string postal, string plan, string days, string comments)
        {
            int numberOfDays = int.Parse(days);

            // Calculate the total amount
            double totalAmount = amount * numberOfDays;

            // Construct the bill using the provided information
            StringBuilder bill = new StringBuilder();

            // Append bill details using the provided registration information
            bill.AppendLine($"Name: {name}");
            bill.AppendLine($"Email: {email}");
            bill.AppendLine($"Event Type: {type}");
            bill.AppendLine($"Contact: {contact}");
            bill.AppendLine($"Address: {address}");
            bill.AppendLine($"Province: {province}");
            bill.AppendLine($"City: {city}");
            bill.AppendLine($"Postal Code: {postal}");
            bill.AppendLine($"Type of Plan: {plan}");
            bill.AppendLine($"Number of Days: {days}");
            bill.AppendLine($"Comments: {comments}");
            bill.AppendLine($"Total Amount: ${totalAmount}");


            // Add your company name (emphasized)
            string companyName = "***** Eventrix *****";

            // Add a thank you message
            string closingMessage = "Thank you for choosing Eventrix for your event management needs. We will ensure your event is styled perfectly!";

            // Append company name and closing message
            bill.AppendLine($"\n\n{companyName}");
            bill.AppendLine($"{closingMessage}");

            bill.AppendLine($"\n\n");

            // Add today's date and time when the bill is generated
            string currentDate = DateTime.Now.ToString("MMMM dd, yyyy");
            string currentTime = DateTime.Now.ToString("hh:mm tt");
            bill.AppendLine($"Date:{currentDate}");
            bill.AppendLine($"Time: {currentTime}");

            return bill.ToString();
        }

        private bool IsValidEmail(string email)
        {
            // Email regex pattern
            string emailPattern = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";

            return Regex.IsMatch(email, emailPattern);
        }

        private void HomeButton_Click5(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("Home.xaml", UriKind.Relative));
        }

        private void FeedbackButton_Click5(object sender, RoutedEventArgs e)
        {
            // Navigate to the FeedbackPage
            NavigationService.Navigate(new Uri("FeedbackPage.xaml", UriKind.Relative));
        }

        private void ContactButton_Click5(object sender, RoutedEventArgs e)
        {
            // Navigate to the ContactPage
            NavigationService.Navigate(new Uri("ContactPage.xaml", UriKind.Relative));
        }
        private void RegisterButton_Click5(object sender, RoutedEventArgs e)
        {
            // Navigate to the ContactPage
            NavigationService.Navigate(new Uri("Register.xaml", UriKind.Relative));
        }

        private void txtComments_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
