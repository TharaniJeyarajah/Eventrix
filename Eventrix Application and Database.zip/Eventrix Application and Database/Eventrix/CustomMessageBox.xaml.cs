﻿using System.Windows;

namespace Eventrix
{
    public partial class CustomMessageBox : Window
    {
        public string Message { get; set; }

        public CustomMessageBox(string message)
        {
            InitializeComponent();
            Message = message;
            DataContext = this;
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
