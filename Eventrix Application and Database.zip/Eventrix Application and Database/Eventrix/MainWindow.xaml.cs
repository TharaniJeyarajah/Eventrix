﻿using System;
using System.Windows;

namespace Eventrix
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void HomeButton_Click(object sender, RoutedEventArgs e)
        {
            mainFrame.NavigationService.Navigate(new Uri("Home.xaml", UriKind.Relative));
        }

        private void FeedbackButton_Click(object sender, RoutedEventArgs e)
        {
            // Navigate to the FeedbackPage
            mainFrame.NavigationService.Navigate(new Uri("FeedbackPage.xaml", UriKind.Relative));
        }

        private void ContactButton_Click(object sender, RoutedEventArgs e)
        {
            // Navigate to the ContactPage
            mainFrame.NavigationService.Navigate(new Uri("ContactPage.xaml", UriKind.Relative));
        }
    }
}
